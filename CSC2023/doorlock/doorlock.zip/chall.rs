use rand::distributions::{Alphanumeric, DistString};

// Generate a random key
fn generate_key(len: usize) -> String {
    Alphanumeric.sample_string(&mut rand::thread_rng(), len)
}

// Convert plain text to hex string
fn plain2hex(s: &str) -> String {
    let hex: Vec<_> = s.bytes().map(|c| format!("{:02X}", c)).collect();

    hex.join("")
}

// Encode string with random key
fn encode(s: &str, n: usize) -> String {
    let key = generate_key(n);
    let key: Vec<u8> = key.bytes().collect();

    let mut s = String::from(s);

    // Pop and Push
    for _ in 0..n {
        let c = s.pop();
        s.insert(0, c.unwrap());
    }

    // Xor
    let s: Vec<_> = s.bytes().enumerate().map(|(i, c)| c ^ key[i % n]).collect();

    String::from_utf8(s).unwrap()
}

const FLAG: &str = "FLAG{...}";
const KEY_LEN: usize = 5;

fn main() {
    /*
    let encoded_flag = encode(FLAG, KEY_LEN);
    println!("encoded_flag @ {}", plain2hex(&encoded_flag));
    */

    println!("encoded_flag @ {}", "5067491628217439052E156D2B160A2E0D272A61355C27700A150B4C060A0E4B36");
}
