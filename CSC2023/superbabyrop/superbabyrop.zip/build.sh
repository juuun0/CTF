#!/bin/sh
docker build -t superbabyrop .