docker stop superbabyrop
docker rm superbabyrop
docker run -d --restart unless-stopped --name superbabyrop -p 5555:5555 superbabyrop