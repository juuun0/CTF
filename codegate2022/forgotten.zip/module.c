#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/module.h>
#include <linux/device.h>
#include <linux/i2c.h>
#include <linux/i2c-algo-bit.h>
#include <linux/platform_device.h>
#include <linux/slab.h>
#include <linux/io.h>
#include <linux/pci.h>
#include <linux/cdev.h>
#include <linux/fs.h>
#include <linux/kthread.h>
#include <linux/highmem.h>
#include <linux/of.h>
#include <linux/scatterlist.h>
#include <linux/swap.h>
#include <linux/list.h>
#include <linux/mmzone.h>
#include <linux/idr.h>
#include <linux/mm.h>
#include <linux/mman.h>
#include <linux/sched.h>

#include <asm/uaccess.h>
#include <asm/page.h>

#define KB(x) ((uint64_t)(x) << 10)
#define MB(x) ((uint64_t)(x) << 20)

#define DEBUG
#undef DEBUG
#ifdef DEBUG
#define LOGV(...)                                                          \
{                                                                          \
    printk(KERN_ALERT __VA_ARGS__);                                        \
}
#else
#define LOGV(...)
#endif

struct codegate_pci_dev {
    uint64_t bus_addr_start;
    uint64_t bus_addr_end;
    uint64_t bus_length;
    void *vaddr;
} g_codegate_pci_dev;

static struct pci_device_id codegate_ids[] = {
    { PCI_DEVICE(0xddaa, 0xddaa) },
    { 0 }
};
MODULE_DEVICE_TABLE(pci, codegate_ids);

#define DEVICE_NAME "cgs3d"

#define MAX_NR_PAGE 128
#define CGS_ORDER 0
#define CGS_MEM_WRITE 0xC0DEC0DE

struct cgs_page_pool {
    int page_count;
    unsigned int reserved_pages;
    bool allocation_allowed;
    unsigned int max_pages;
    spinlock_t list_lock;  
    struct list_head page_list;
};

struct cgs_page_pool cgs_pool;

struct cgs_memdesc {
    unsigned int vmflags;
    uint64_t useraddr;
    uint64_t cgsaddr;
    uint64_t size;
    unsigned int priv;
    struct page **pages;
    unsigned int page_count;
    struct cgs_pagetable *pagetable;
};

struct cgs_mem_entry {
    struct kref refcount;
    struct cgs_memdesc memdesc;
    void *priv_data;
    struct rb_node node;
    unsigned int id;
    int pending_free;
    struct work_struct work;
    spinlock_t bind_lock;
    struct rb_root bind_tree;
};

static inline int cgs_mem_entry_get(struct cgs_mem_entry *entry);
static inline void cgs_mem_entry_put(struct cgs_mem_entry *entry);

struct cgs_pagetable;
struct cgs_mmu_pt_ops {
    int (*mmu_map)(struct cgs_pagetable *pt,
            struct cgs_memdesc *memdesc);
    int (*mmu_unmap)(struct cgs_pagetable *pt,
            struct cgs_memdesc *memdesc);
    void (*mmu_destroy_pagetable)(struct cgs_pagetable *pt);
    int (*get_cgsaddr)(struct cgs_pagetable *pt,
            struct cgs_memdesc *memdesc);
    void (*put_cgsaddr)(struct cgs_pagetable *pt,
            uint64_t cgsaddr);
};

struct cgs_iommu_pt {
    bool attached;
    struct rb_root rbtree;
    uint64_t cgs_start;
    uint64_t cgs_end;
};

struct cgs_iommu_addr_entry {
    uint64_t va_start;
    uint64_t base;
    uint64_t size;
    struct rb_node node;
};

struct cgs_mmu;
struct cgs_pagetable {
    spinlock_t lock;
    struct kref refcount;
    struct list_head list;
    const struct cgs_mmu_pt_ops *pt_ops;
    uint64_t fault_addr;
    void *priv;
    struct cgs_mmu *mmu;
};

static struct kmem_cache *addr_entry_cache;

static struct cgs_iommu_addr_entry *find_cgsaddr(
		struct cgs_pagetable *pagetable, uint64_t cgsaddr) {
	struct cgs_iommu_pt *pt = pagetable->priv;
	struct rb_node *node = pt->rbtree.rb_node;

	while (node != NULL) {
		struct cgs_iommu_addr_entry *entry = rb_entry(node,
			struct cgs_iommu_addr_entry, node);

		if (cgsaddr < entry->base)
			node = node->rb_left;
		else if (cgsaddr > entry->base)
			node = node->rb_right;
		else
			return entry;
	}

	return NULL;
}

static int remove_cgsaddr(struct cgs_pagetable *pagetable,
		uint64_t cgsaddr) {
	struct cgs_iommu_pt *pt = pagetable->priv;
	struct cgs_iommu_addr_entry *entry;

	entry = find_cgsaddr(pagetable, cgsaddr);

	if (entry != NULL) {
		rb_erase(&entry->node, &pt->rbtree);
		kmem_cache_free(addr_entry_cache, entry);
		return 0;
	}

	LOGV("Couldn't remove cgsaddr: 0x%llx\n", cgsaddr);
	return -ENOMEM;
}

static int insert_cgsaddr(struct cgs_pagetable *pagetable, struct cgs_memdesc *memdesc,
		uint64_t cgsaddr, uint64_t size, bool mapped) {
	struct cgs_iommu_pt *pt = pagetable->priv;
	struct rb_node **node, *parent = NULL;
	struct cgs_iommu_addr_entry *new =
		kmem_cache_alloc(addr_entry_cache, GFP_ATOMIC);

	if (new == NULL)
		return -ENOMEM;

    if (mapped)
        new->va_start = page_to_virt(memdesc->pages[0]);
    else
        new->va_start = 0;
	new->base = cgsaddr;
	new->size = size;

	node = &pt->rbtree.rb_node;

	while (*node != NULL) {
		struct cgs_iommu_addr_entry *this;

		parent = *node;
		this = rb_entry(parent, struct cgs_iommu_addr_entry, node);

		if (new->base < this->base)
			node = &parent->rb_left;
		else if (new->base > this->base)
			node = &parent->rb_right;
		else {
            LOGV("duplicated...\n");
			kmem_cache_free(addr_entry_cache, new);
			return -EEXIST;
		}
	}

	rb_link_node(&new->node, parent, node);
	rb_insert_color(&new->node, &pt->rbtree);
	return 0;
}

static bool iommu_addr_in_cgs_ranges(struct cgs_iommu_pt *pt,
	u64 cgsaddr, u64 size) {
	if ((cgsaddr >= pt->cgs_start && cgsaddr < pt->cgs_end) &&
		((cgsaddr + size) > pt->cgs_start &&
			(cgsaddr + size) <= pt->cgs_end))
		return true;

	return false;
}

static int iommu_set_cgs_region(struct cgs_pagetable *pagetable, struct cgs_memdesc *memdesc,
        uint64_t cgsaddr, uint64_t size) {
    int ret = -ENOMEM;
    struct cgs_iommu_pt *pt = pagetable->priv;
    struct rb_node *node;

    if (!iommu_addr_in_cgs_ranges(pt, cgsaddr, size))
        return -ENOMEM;

    spin_lock(&pagetable->lock);
    node = pt->rbtree.rb_node;
    while (node != NULL) {
        uint64_t start, end;
        struct cgs_iommu_addr_entry *entry = rb_entry(node,
                struct cgs_iommu_addr_entry, node);

        start = entry->base;
        end = entry->base + entry->size;

        if (cgsaddr  + size <= start)
            node = node->rb_left;
        else if (end <= cgsaddr)
            node = node->rb_right;
        else
            goto out;
    }

    ret = insert_cgsaddr(pagetable, memdesc, cgsaddr, size, true);
out:
    spin_unlock(&pagetable->lock);
    return ret;
}

void mmu_put_cgsaddr(struct cgs_pagetable *pagetable, uint64_t cgsaddr) {
    spin_lock(&pagetable->lock);
    remove_cgsaddr(pagetable, cgsaddr);
    spin_unlock(&pagetable->lock);
}

void cgs_mmu_put_cgsaddr(struct cgs_memdesc *memdesc) {
    struct cgs_pagetable *pagetable = memdesc->pagetable;
    if (memdesc->size == 0 || memdesc->cgsaddr == 0)
        return;

    if (pagetable && pagetable->pt_ops && pagetable->pt_ops->put_cgsaddr)
        pagetable->pt_ops->put_cgsaddr(pagetable, memdesc->cgsaddr);

    memdesc->cgsaddr = 0;
    memdesc->pagetable = NULL;
}

static uint64_t _get_unmapped_area(struct cgs_pagetable *pagetable,
		uint64_t bottom, uint64_t top, uint64_t size,
		uint64_t align) {
	struct cgs_iommu_pt *pt = pagetable->priv;
	struct rb_node *node = rb_first(&pt->rbtree);
	uint64_t start;

	bottom = ALIGN(bottom, align);
	start = bottom;

	while (node != NULL) {
		uint64_t gap;
		struct cgs_iommu_addr_entry *entry = rb_entry(node,
			struct cgs_iommu_addr_entry, node);

		if (entry->base < bottom) {
			if (entry->base + entry->size > bottom)
				start = ALIGN(entry->base + entry->size, align);
			node = rb_next(node);
			continue;
		}

		if (entry->base >= top)
			break;

		if (start < entry->base) {
			gap = entry->base - start;

			if (gap >= size)
				return start;
		}

		if (entry->base + entry->size >= top)
			return (uint64_t) -ENOMEM;

		start = ALIGN(entry->base + entry->size, align);
		node = rb_next(node);
	}

	if (start + size <= top)
		return start;

	return (uint64_t) -ENOMEM;
}

int mmu_get_cgsaddr(struct cgs_pagetable *pagetable, struct cgs_memdesc *memdesc) {
    int ret = 0;
    struct rb_node **node, *parent = NULL;
    struct cgs_iommu_pt *pt = pagetable->priv;

    if (!memdesc->pages || !memdesc->page_count) {
        return -ENOMEM;
    }

    spin_lock(&pagetable->lock);
    uint64_t addr = _get_unmapped_area(pagetable, pt->cgs_start, pt->cgs_end, memdesc->size, PAGE_SIZE);
    if (addr == (uint64_t)-ENOMEM) {
        ret = -ENOMEM;
        goto out;
    }

    ret = insert_cgsaddr(pagetable, memdesc, addr, memdesc->size, false);
    if (ret == 0) {
        memdesc->cgsaddr = addr;
        memdesc->pagetable = pagetable;
    }

out:
    spin_unlock(&pagetable->lock);
    return ret;
}

void mmu_put_cgsaddr(struct cgs_pagetable *pagetable, uint64_t cgsaddr);
struct cgs_mmu_pt_ops cgs_pagetable_ops = {
    .mmu_map = NULL,
    .mmu_unmap = NULL,
    .mmu_destroy_pagetable = NULL,
    .get_cgsaddr = mmu_get_cgsaddr,
    .put_cgsaddr = mmu_put_cgsaddr,
};

struct cgs_mmu {
    struct cgs_pagetable *pagetable;
};

struct cgs_driver {
    int major;
    struct device *dev;
    struct class *class;

    struct list_head process_list;
    struct list_head pagetable_list;

    spinlock_t ptlock;
    struct mutex process_mutex;
    spinlock_t proclist_lock;
    struct mutex devlock;

    struct cgs_mmu *mmu;
} cgs_driver;

struct cgs_private {
    struct cgs_pagetable *pagetable;
    spinlock_t mem_lock;
    struct idr mem_idr;
};

int cgs_alloc_page(struct cgs_memdesc *memdesc, uint64_t size);
void cgs_free_page(struct page *);
void cgs_free_pages(struct cgs_memdesc *);

void cgs_pool_add_page(struct cgs_page_pool *pool);
void cgs_pool_free_page(struct cgs_page_pool *pool, struct page *page);

static int cgs_open(struct inode *inodep, struct file *filep) {
    int ret = 0;
    mutex_lock(&cgs_driver.devlock);
    void *device = (void *)cgs_driver.dev;
    if (!device) {
        LOGV("cgs : no device (cgs_open error)\n");
        return -ENODEV;
    }

    struct cgs_private *private = (struct cgs_private *)kmalloc(sizeof(struct cgs_private), GFP_KERNEL);
    if (!private) {
        return -ENOMEM;
    }
    memset(private, 0, sizeof(*private));



    private->pagetable = (struct cgs_pagetable *)kmalloc(sizeof(struct cgs_pagetable), GFP_KERNEL);
    if (!private->pagetable) {
        return -ENOMEM;
    }

    memset(private->pagetable, 0, sizeof(*private->pagetable));
    private->pagetable->pt_ops = &cgs_pagetable_ops;

    idr_init(&private->mem_idr);
    spin_lock_init(&private->mem_lock);
    spin_lock_init(&private->pagetable->lock);


    if (addr_entry_cache == NULL) {
        addr_entry_cache = KMEM_CACHE(cgs_iommu_addr_entry, 0);
        if (addr_entry_cache == NULL) {
            ret = -ENOMEM;
            goto err;
        }
    }


    struct cgs_iommu_pt *iommu_pt;
    iommu_pt = kzalloc(sizeof(struct cgs_iommu_pt), GFP_KERNEL);
    if (!iommu_pt) {
        return -ENOMEM;
    }

    iommu_pt->cgs_start = g_codegate_pci_dev.bus_addr_start;
    iommu_pt->cgs_end = g_codegate_pci_dev.bus_addr_end;

    private->pagetable->priv = iommu_pt;
    private->pagetable->fault_addr = ~0ULL;
    iommu_pt->rbtree = RB_ROOT;

    filep->private_data = private;
err:
    mutex_unlock(&cgs_driver.devlock);
    return ret;
}

static int cgs_release(struct inode *inodep, struct file *filep) {
    mutex_lock(&cgs_driver.devlock);

    mutex_unlock(&cgs_driver.devlock);
    return 0;
}

#define CGS_ALLOC       0xc0de0000
#define CGS_FREE        0xc0de0001
#define CGS_SUBMIT      0xc0de0002

struct cgs_alloc_helper {
    unsigned int id;
    size_t size;
    size_t padd;
    uint64_t cgsaddr;
};

struct cgs_free_helper {
    unsigned int id;
};

struct cgs_submit_helper {
    unsigned int *cmds;
    unsigned int index;
};

int cgs_mmu_get_addr(struct cgs_pagetable *pagetable, struct cgs_memdesc *memdesc) {
    if (!pagetable->pt_ops || !pagetable->pt_ops->get_cgsaddr) {
        return -ENOMEM;
    }
    return pagetable->pt_ops->get_cgsaddr(pagetable, memdesc);
}

int cgs_mem_entry_attach(struct cgs_private *private, struct cgs_mem_entry *entry) {
    int ret = 0; 
    int id = 0;


    struct cgs_pagetable *pagetable = private->pagetable;


    ret = cgs_mmu_get_addr(pagetable, &entry->memdesc);


    idr_preload(GFP_KERNEL);
    spin_lock(&private->mem_lock);
    id = idr_alloc(&private->mem_idr, NULL, 1, 0, GFP_NOWAIT);
    spin_unlock(&private->mem_lock);
    idr_preload_end();

    if (id < 0) {
    
        return id;
    }

    entry->id = id;
    entry->priv_data = (void *)private;


    spin_lock(&private->mem_lock);
    idr_replace(&private->mem_idr, entry, entry->id);
    spin_unlock(&private->mem_lock);

    return ret;
}

struct cgs_mem_entry *cgs_entry_create(void) {
    struct cgs_mem_entry *entry = kzalloc(sizeof(*entry), GFP_KERNEL);
    if (entry != NULL) {
        kref_init(&entry->refcount);
        kref_get(&entry->refcount);
    }

    return entry;
}

static int cgs_ioctl_alloc(struct cgs_private *private, unsigned long arg) {
    int ret = 0;
    struct cgs_alloc_helper param;
    struct cgs_mem_entry *entry;
    if (copy_from_user(&param, (__user void *)arg, sizeof(param))) {
        return -EFAULT;
    }

    entry = cgs_entry_create();
    if (!entry) {
        return -EINVAL;
    }

    ret = cgs_alloc_page(&entry->memdesc, param.size);
    if (ret) {
    
        goto done;
    }

    ret = cgs_mem_entry_attach(private, entry);
    if (ret) {
    
        goto done;
    }

    memset(&param, 0, sizeof(param));
    param.id = entry->id;

    param.cgsaddr = entry->memdesc.cgsaddr;


    cgs_mem_entry_put(entry);

    if (copy_to_user((__user void *)arg, &param, sizeof(param))) {
        return -EFAULT;
    }

done:
    return ret;
}

int cgs_mem_free_entry(struct cgs_mem_entry *entry) {
    int ret = 0;
    entry->pending_free = 1;
    cgs_mem_entry_put(entry);
    return ret;
}

struct cgs_mem_entry *cgs_find_id(struct cgs_private *private, unsigned int id);
static int cgs_ioctl_free(struct cgs_private *private, unsigned long arg) {
    struct cgs_free_helper param;
    struct cgs_mem_entry *entry;
    int ret = 0;
    if (copy_from_user(&param, (__user void *)arg, sizeof(param))) {
        return -EFAULT;
    }
    
    entry = cgs_find_id(private, param.id);

    if (!entry) {
        return -EINVAL;
    }

	ret = cgs_mem_free_entry(entry);
	cgs_mem_entry_put(entry);

    return ret;
}

static int cgs_ioctl_submit(struct cgs_private *private, unsigned long arg) {
    struct cgs_submit_helper param;
    uint64_t *vptr = NULL;
    if (copy_from_user(&param, (__user void *)arg, sizeof(param)))
        return -EFAULT;
    
    uint32_t *cmds = (uint32_t *)kmalloc(PAGE_SIZE, GFP_KERNEL);
    if (!cmds) 
        return -ENOMEM;

    memset(cmds, 0, PAGE_SIZE);
    if (copy_from_user((void *)cmds, (__user void *)param.cmds, PAGE_SIZE))
        return -EFAULT;

    if (*cmds != CGS_MEM_WRITE)
        return -EINVAL;

    struct cgs_iommu_addr_entry *entry = find_cgsaddr(private->pagetable, *(++cmds));
    if (!entry)
        return -EINVAL;

    if (!entry->va_start)
        return -EINVAL;

    vptr = (uint64_t *)entry->va_start;
    if (param.index >= (0x1000 / 8))
        return -EINVAL;

    vptr[param.index] = *(uint64_t *)(++cmds);
    kfree(cmds);
    return 0;
}

static long cgs_ioctl(struct file *filep, unsigned int cmd, unsigned long arg) {
    int ret = 0;
    mutex_lock(&cgs_driver.devlock);
    struct cgs_private *private = (struct cgs_private *)filep->private_data;
    switch (cmd) {
        case CGS_ALLOC:
            ret = cgs_ioctl_alloc(private, arg);
            break;
        case CGS_FREE:
            ret = cgs_ioctl_free(private, arg);
            break;
        case CGS_SUBMIT:
            ret = cgs_ioctl_submit(private, arg);
            break;
    }
    mutex_unlock(&cgs_driver.devlock);
    return ret;
}

static void cgs_vm_open(struct vm_area_struct *vma) {
	struct cgs_mem_entry *entry = vma->vm_private_data;
    if (cgs_mem_entry_get(entry) == 0) {
        vma->vm_private_data = NULL;
    }
}

static int
cgs_vm_fault(struct vm_fault *vmf) {
	struct cgs_mem_entry *entry = vmf->vma->vm_private_data;

	if (!entry)
		return VM_FAULT_SIGBUS;

	return 0;
}

static void
cgs_vm_close(struct vm_area_struct *vma) {
	struct cgs_mem_entry *entry  = vma->vm_private_data;

	if (!entry)
		return;
    
    entry->memdesc.useraddr = 0;
    cgs_mem_entry_put(entry);
}

static const struct vm_operations_struct cgs_vm_ops = {
	.open  = cgs_vm_open,
	.fault = cgs_vm_fault,
	.close = cgs_vm_close,
};

void cgs_mem_entry_detach_process(struct cgs_mem_entry *entry) {
    struct cgs_private *private = entry->priv_data;
    spin_lock(&private->mem_lock);
    if (entry->id != 0) 
        idr_remove(&private->mem_idr, entry->id);

    entry->id = 0;
    spin_unlock(&private->mem_lock);

    cgs_mmu_put_cgsaddr(&entry->memdesc);
    entry->priv_data = NULL;
}

void cgs_free(struct page **pages) {
    kfree(pages);
}

void cgs_pool_free_pages(struct page **pages, unsigned int pcount) {
    int i;
    if (pages == NULL || pcount == 0) 
        return;

    for (i = 0; i < pcount; i++) {
        struct page *p = pages[i];
    
        if (cgs_pool.page_count < MAX_NR_PAGE) {
            cgs_pool_free_page(&cgs_pool, p);
            continue;
        }
        
    
        __free_pages(p, CGS_ORDER);
    }
}

void cgs_page_free(struct cgs_memdesc *memdesc) {

    if (memdesc->pages != NULL)
        cgs_pool_free_pages(memdesc->pages, memdesc->page_count);
}

void cgs_free_internal(struct cgs_memdesc *memdesc) {
    if (memdesc == NULL || memdesc->size == 0)
        return;

    cgs_page_free(memdesc);

    if (memdesc->pages)
        cgs_free(memdesc->pages);
}

void cgs_mem_entry_destroy(struct kref *kref) {
    struct cgs_mem_entry *entry =
        container_of(kref, struct cgs_mem_entry, refcount);


    cgs_mem_entry_detach_process(entry);
    cgs_free_internal(&entry->memdesc);

    kfree(entry);
}

static inline int
cgs_mem_entry_get(struct cgs_mem_entry *entry) {
    if (entry)
        return kref_get_unless_zero(&entry->refcount);
    return 0;
}

static inline void
cgs_mem_entry_put(struct cgs_mem_entry *entry) {
    if (entry)
        kref_put(&entry->refcount, cgs_mem_entry_destroy);
}

struct cgs_mem_entry *
cgs_find_id(struct cgs_private *private, unsigned int id) {
    struct cgs_mem_entry *entry;
    spin_lock(&private->mem_lock);
    entry = idr_find(&private->mem_idr, id);
    if (entry) {
        int count = cgs_mem_entry_get(entry);
        if (count == 0) {
            entry = NULL;
        }
    }
    spin_unlock(&private->mem_lock);
    return entry;
}

int cgs_get_mmap_entry(struct cgs_private *private, struct cgs_mem_entry **out_entry,
        unsigned long pgoff, unsigned long len) {
    int ret = 0;
    struct cgs_mem_entry *entry;
    spin_lock(&private->mem_lock);
    entry = idr_find(&private->mem_idr, pgoff);
    if (entry) {
        int count = cgs_mem_entry_get(entry);
        if (count == 0) {
            entry = NULL;
        }
    }
    spin_unlock(&private->mem_lock);

    if (!entry) {
        return -EINVAL;
    }

    if (entry->memdesc.useraddr != 0) {
        ret = -EBUSY;
        goto err;
    }

    *out_entry = entry;
    return 0;

err:
    cgs_mem_entry_put(entry);
    return ret;
}

static int cgs_mmap(struct file *file, struct vm_area_struct *vma) {
    struct cgs_private *private = file->private_data;
    struct cgs_mem_entry *entry = NULL;
    int ret = 0;
    int i = 0;

    mutex_lock(&cgs_driver.devlock);
    ret = cgs_get_mmap_entry(private, &entry, 
            vma->vm_pgoff, vma->vm_end - vma->vm_start);

    if (ret) {
        return ret;
    }

    vma->vm_flags = VM_READ;
    vma->vm_private_data = entry;
    vma->vm_ops = &cgs_vm_ops;

    uint64_t addr = (uint64_t)vma->vm_start;
    for (i = 0; i < entry->memdesc.page_count; i++) {
        struct page *p = entry->memdesc.pages[i];
        vm_insert_page(vma, addr, p);
        addr += PAGE_SIZE;

        if (addr == vma->vm_end)
            break;
    }

    vma->vm_file = file;

    entry->memdesc.useraddr = vma->vm_start;

    mutex_unlock(&cgs_driver.devlock);
    return 0;
}

unsigned long cgs_set_region(struct cgs_private *private,
        struct cgs_mem_entry *entry, unsigned long hint,
        unsigned long len) {
    int ret;
    struct cgs_pagetable *pagetable = private->pagetable;
    
    ret = iommu_set_cgs_region(private->pagetable, &entry->memdesc,
            (uint64_t)hint, (uint64_t)len);

    if (ret != 0) 
        return ret;

    entry->memdesc.cgsaddr = (uint64_t)hint;
    entry->memdesc.pagetable = pagetable;

    return hint;
}

static unsigned long get_cgs_area(struct cgs_private *private,
		struct cgs_mem_entry *entry, unsigned long hint,
		unsigned long len, unsigned long flags) {
    unsigned long result = hint;

    if (flags & MAP_FIXED) {
        if (!IS_ALIGNED(hint, PAGE_SIZE))
            return -EINVAL;

        return cgs_set_region(private, entry, hint, len);
    } else {
        return  -EINVAL;
    }
    
    return result;
}

static unsigned long
cgs_get_unmapped_area(struct file *file, unsigned long addr,
			unsigned long len, unsigned long pgoff,
            unsigned long flags) {
    unsigned long val;
    struct cgs_private *private = file->private_data;
    struct cgs_mem_entry *entry = NULL;
	val = cgs_get_mmap_entry(private, &entry, pgoff, len);
	if (val)
		return val;

    LOGV("cgs : cgs_get_unmapped_area\n");

    val = get_cgs_area(private, entry, addr, len, flags);

    cgs_mem_entry_put(entry);    
    return val;
}

static struct file_operations cgs_fops = {
    .owner = THIS_MODULE,
    .mmap = cgs_mmap,
    .get_unmapped_area = cgs_get_unmapped_area,
    .unlocked_ioctl = cgs_ioctl,
    .open = cgs_open,
    .release = cgs_release
};

#define CGS_DRIVER_NAME "cgs-3d0"
static int cgs_driver_register(void) { 
    int result = 0;

    cgs_driver.major = register_chrdev(0, CGS_DRIVER_NAME, &cgs_fops);
    if (cgs_driver.major < 0) {
        LOGV("cgs : fail to register chrdev\n");
        goto err;
    }

    cgs_driver.class = class_create(THIS_MODULE, CGS_DRIVER_NAME);
    if (IS_ERR(cgs_driver.class)) {
        result = PTR_ERR(cgs_driver.class);
        LOGV("cgs : fail to create class\n");
        goto err;
    }

    INIT_LIST_HEAD(&cgs_driver.process_list);
    INIT_LIST_HEAD(&cgs_driver.pagetable_list);

    cgs_driver.dev = device_create(cgs_driver.class, NULL, MKDEV(cgs_driver.major, 0), NULL, CGS_DRIVER_NAME);
    if (IS_ERR(cgs_driver.dev)) {
        LOGV("cgs : fail to create device");
        class_destroy(cgs_driver.class);
        unregister_chrdev(cgs_driver.major, CGS_DRIVER_NAME);
        goto err;
    }

    mutex_init(&cgs_driver.devlock);

    LOGV("cgs : success to register, %d\n", cgs_driver.major);
    return 0;

err:
    return result;
};

static int codegate_probe(struct pci_dev *dev, const struct pci_device_id *id) {
    u8 revision;
    uint64_t phys;
    pci_enable_device(dev);
    pci_read_config_byte(dev, PCI_REVISION_ID, &revision);

    if (revision != 0x69) {
        return -ENODEV;
    }

    g_codegate_pci_dev.bus_addr_start = pci_resource_start(dev, 0);
    g_codegate_pci_dev.bus_addr_end = pci_resource_end(dev, 0);
    g_codegate_pci_dev.bus_length = pci_resource_len(dev, 0);

    pci_request_regions(dev, "cgs");
    g_codegate_pci_dev.vaddr = (void *)ioremap(
            g_codegate_pci_dev.bus_addr_start,
            g_codegate_pci_dev.bus_length);

    phys = __pa_symbol(init_mm.start_code);
    memcpy(g_codegate_pci_dev.vaddr, &phys, 8);

    return 0;
}

static unsigned long
cgs_pool_shrink_scan_objects(struct shrinker *shrinker,
        struct shrink_control *sc) {
    LOGV("cgs_pool_shrink_scan_objects is called\n");
    return 0;
}

static unsigned long
cgs_pool_shrink_count_objects(struct shrinker *shrinker,
        struct shrink_control *sc) {
    LOGV("cgs_pool_shrink_count_objects is called\n");
    return 0;
}

static struct shrinker cgs_pool_shrinker = {
    .count_objects = cgs_pool_shrink_count_objects,
    .scan_objects = cgs_pool_shrink_scan_objects,
    .seeks = DEFAULT_SEEKS,
    .batch = 0,
};

void cgs_zero_page(struct page *p, unsigned int order) {
    int i;

    for (i = 0; i < (1 << order); i++) {
        struct page *page = nth_page(p, i);
        void *addr = kmap_atomic(page);

        memset(addr, 0, PAGE_SIZE);
        kunmap_atomic(addr);
    }
}

int cgs_alloc_page(struct cgs_memdesc *memdesc, uint64_t size) {
    uint64_t len;
    int ret = 0;
    int page_count = 0;
    uint32_t len_alloc = 0;
    size = PAGE_ALIGN(size);
    if (size == 0 || size > UINT_MAX)
        return -EINVAL;

    len_alloc = PAGE_ALIGN(size) >> PAGE_SHIFT;


    memdesc->pages = kmalloc(len_alloc * sizeof(struct page *), GFP_KERNEL);
    memset(memdesc->pages, 0, len_alloc * sizeof(struct page *));
    memdesc->page_count = 0;
    memdesc->size = size;
    memdesc->vmflags = VM_DONTDUMP | VM_PFNMAP | VM_DONTEXPAND | VM_DONTCOPY;

    if (memdesc->pages == NULL) {
        ret = -ENOMEM;
        goto done;
    }

    len = size;

    while (len > 0) {
        struct page *p = NULL;
        spin_lock(&cgs_pool.list_lock);
        if (cgs_pool.page_count) {
            p = list_first_entry(&cgs_pool.page_list, struct page, lru);
            cgs_pool.page_count--;
            list_del(&p->lru);

            LOGV("page from pool !! %#llx\n", (uint64_t)p);
        }
        spin_unlock(&cgs_pool.list_lock);

    
    
        if (!p) {
            p = alloc_pages(GFP_KERNEL, CGS_ORDER);
            LOGV("alloc_pages is called : %#x, %#llx\n", memdesc->page_count, (uint64_t)p);
        
            if (!p) {
                ret = -ENOMEM;
                goto done;
            }

        
            cgs_zero_page(p, CGS_ORDER);
        }   

        memdesc->page_count++;
        memdesc->pages[page_count++] = p;
        len -= PAGE_SIZE;
    }

done:
    if (ret) {
        if (memdesc->pages) {
            int i;
        
            for (i = 0; i < page_count; i++) {
                put_page(memdesc->pages[i]);
            }
        }
        memset(memdesc->pages, 0, len_alloc * sizeof(struct page *));
        kfree(memdesc->pages);
        memset(memdesc, 0, sizeof(*memdesc));
    }

    return ret;
}

void cgs_free_pages(struct cgs_memdesc *memdesc) {
    int i = 0;
    for (i = 0; i < memdesc->page_count; i++)
        if (memdesc->pages[i])
            put_page(memdesc->pages[i]);
}

void cgs_free_page(struct page *p) {
    put_page(p);
}

void cgs_pool_free_page(struct cgs_page_pool *pool, struct page *p) { 
    cgs_zero_page(p, CGS_ORDER);
    spin_lock(&pool->list_lock);
    list_add_tail(&p->lru, &pool->page_list);
    pool->page_count++;
    spin_unlock(&pool->list_lock);
};

void cgs_pool_add_page(struct cgs_page_pool *pool) {
    struct page *p = alloc_pages(GFP_KERNEL, CGS_ORDER);
    cgs_zero_page(p, CGS_ORDER);
    spin_lock(&pool->list_lock);
    list_add_tail(&p->lru, &pool->page_list);
    pool->page_count++;
    spin_unlock(&pool->list_lock);
}

void cgs_pool_reserve_pages(void) {
    int i;
    cgs_pool.reserved_pages = MAX_NR_PAGE;
    cgs_pool.allocation_allowed = false;
    cgs_pool.max_pages = MAX_NR_PAGE;
    INIT_LIST_HEAD(&cgs_pool.page_list);
    for (i = 0; i < MAX_NR_PAGE; i++) {
        cgs_pool_add_page(&cgs_pool);
    }

    LOGV("cgs : cgs_pool_reserve_pages is success\n");
}

void cgs_init_page_pools(void) {
    cgs_pool_reserve_pages();
    register_shrinker(&cgs_pool_shrinker);
    LOGV("cgs : page initialization is done");
}

static void codegate_remove(struct pci_dev *dev) {}
static struct pci_driver codegate_driver = {
    .name = "cgs",
    .id_table = codegate_ids,
    .probe = codegate_probe,
    .remove = codegate_remove,
};

static int __init codegate_init(void) {
    int err = cgs_driver_register();
    if (err) {
        LOGV("cgs : fail to register cgs drvier\n");
        return err;
    }
    
    cgs_init_page_pools();
    err = pci_register_driver(&codegate_driver);
    if (err) {
        LOGV("cgs : fail to register pci drvier\n");
        return err;
    }

    return err;
}

static void __exit codegate_exit(void) {
    pci_unregister_driver(&codegate_driver);
}

module_init(codegate_init);
module_exit(codegate_exit);

MODULE_DESCRIPTION("CGS");
MODULE_ALIAS("cgs-3d");
MODULE_AUTHOR("redacted");
MODULE_LICENSE("GPL");
