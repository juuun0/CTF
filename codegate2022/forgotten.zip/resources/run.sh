#!/bin/sh

/home/forgotten/qemu-system-x86_64 \
    -cpu qemu64,+smep,+smap \
    -kernel /home/forgotten/bzImage \
    -smp 2 \
    -initrd /home/forgotten/initramfs.cpio.gz \
    -nographic \
    -device cgs \
    -append "root=/dev/ram rw console=ttyS0 oops=panic loglevel=2 panic=1 console=ttyS0" \
    -monitor none \
    -no-reboot \
    -m 1G \
